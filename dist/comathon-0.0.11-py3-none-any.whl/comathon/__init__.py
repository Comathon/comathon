# import requests

from .cmt_test import *

print("Comathon Module Imported, GAZUA")
