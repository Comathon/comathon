import requests

url = "http://121.137.95.97:8888/BotList"
response = requests.get(url)
# print(response.json())


url = "http://121.137.95.97:8888/BotWithinUserList?botid=BOT002"
response = requests.get(url)
print(response.json())


